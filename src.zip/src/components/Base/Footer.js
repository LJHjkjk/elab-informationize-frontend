
function Footer(){
  return (
    <footer id='fonter' >
      <div class="text-center">
        <p>这是页脚</p>
      </div>
    </footer>
  )
}

export default Footer;