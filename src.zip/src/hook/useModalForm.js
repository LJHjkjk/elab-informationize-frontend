import { Container, Row,Figure,Image, Col,Card,Table,FloatingLabel,Button,Badge, Modal, Form, Accordion, ListGroup} from 'react-bootstrap';
import { useState } from 'react';
import { useForm ,Controller} from 'react-hook-form';


function ModalForm({}){


}

function useModalForm(){
    const { handleSubmit, control,setValue,formState: { errors }} = useForm();


}

